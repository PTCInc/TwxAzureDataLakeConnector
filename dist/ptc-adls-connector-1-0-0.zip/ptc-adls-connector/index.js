/* begin copyright text
 *
 * Copyright © 2019 PTC Inc., Its Subsidiary Companies, and/or its Partners. All Rights Reserved.
 *
 * end copyright text
 */
const Connector = require('ptc-flow-sdk').Connector

const connector = new Connector(__dirname)
module.exports = connector
