module.exports = {
    testInput : {
        storageAccountName : '',
        storageAccountAccessKey : ''
    },
    testOutput : {
    }
}
